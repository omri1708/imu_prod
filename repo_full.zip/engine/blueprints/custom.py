def generate(spec):
    return {}

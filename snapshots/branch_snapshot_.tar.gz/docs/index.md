# IMU Platform

Welcome to the IMU control-plane.  
באתר זה: מדריכי הפעלה, runbooks, ותרשימי ארכיטקטורה.

- **Deploy:** ראה “Deploy Control Plane”
- **Emergency:** ראה “Emergency Rollback”
- **SLO:** זמינות, p95, Gatekeeper